from datetime import datetime

Name = 1
Brand = 2
Price = 3
Quantity = 4
Processor = 5
Graphic = 6



BILLS_PATH = "./bills/"
SHIPPING_PATH = './stocks/'

user_current_details = {}

def welcome():
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\t\tAngel Electronics")
    print("\tWelcome to Laptop Management System")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")

def list_options():
    print("\n")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")
    print("1. Display Laptops")
    print("2. Purchase Laptops")
    print("3. Add Stock")
    print("4. Exit the Program")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++")

def invalid_input():
    print("The input is invalid")

def display_Laptops():
    print("\n")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("Laptop ID\tLaptop Name\tBrand Name \tPrice \t\tQuantity \tProcessor \t\tGraphics")
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    file = open("Laptop.txt", "r")
    id = 1

    for line in file:
        print(line.replace(",", "\t\t"))
        id = id + 1
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    file.close()

def get_Laptop_list():
    file = open("Laptop.txt", "r")
    id = 1
    Laptops = {}
    for line in file:
        Laptops[id] = line.replace("\n", "").split(",")
        id = id + 1
 
    return Laptops

def add_stock():
    display_Laptops()

    selected_id = 0

    while selected_id == 0:
        try:
            selected_id = int(input("Enter the Laptop id to add the quantity: "))
        except:
            print("Please enter valid Laptop id.")
    
    Laptop_list = get_Laptop_list()
    selected_Laptop = Laptop_list.get(selected_id)

    if selected_Laptop == None:
        print("Laptop not found! Would you like to add new Laptop?\n1. Yes \n2. No")
        yesno = 0

        while yesno < 1 or yesno > 2:
            try:
                yesno = int(input("Enter the value of option: "))

                if yesno > 2:
                    print("\nPlease enter either 1 or 2!\n")
            except:
                print("Please enter either 1 or 2!")

        if yesno == 1:
            add_new_Laptop()
        else:
            add_stock()
    else:
        add_current_stock(selected_id)

def add_current_stock(Laptop_id):
    Laptop_list = get_Laptop_list()
    Laptop = Laptop_list.get(Laptop_id)

    name = Laptop[Name]
    brand = Laptop[Brand]
    price = Laptop[Price]
    processor = Laptop[Processor]
    graphic = Laptop[Graphic]
    shipping_name = input("Enter the name of shipping company: ")
    shipping_address = input("Enter the address of shipping company: ")
    delivery_date = input("Enter the delivery date: ")
    

    Laptop_quantity = 0
    while Laptop_quantity < 1:
        try:
            Laptop_quantity = int(input("Enter the quantity to add: "))
        except:
            print("\nPlease enter a valid number greater than 0\n")
    
    shipping_cost = 0
    while shipping_cost < 1:
        try:
            shipping_cost = int(input("Enter the shipping cost: "))
        except:
            print("\nPlease enter valid cost for devliery!")
    
    amount_paid = int(price.replace("$", "")) * Laptop_quantity
    Vat_amount = amount_paid / 100 * 13
    Total_amount = Vat_amount + shipping_cost + amount_paid
    content = f"""Shipping company: {shipping_name} \nShipping Address: {shipping_address}  \nDelivery Date: {delivery_date} \nShipping Cost: {shipping_cost} \nVat Amount: {Vat_amount} \n\nLaptop Name: {name} \nBrand Name: {brand} \nQuantity: {Laptop_quantity} \nPrice: {price} \nAmount paid: ${amount_paid} \nVAt amount: {Vat_amount} \nTotal amount(with Vat amount): {Total_amount}"""

    time_today = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    file_name = SHIPPING_PATH + shipping_name + "_" + time_today + ".txt"
    file = open(file_name, "w")
    file.write(content)
    file.close()

    add_Laptop_stock(Laptop_id, Laptop_quantity)

    print("\nSuccessfully added the quantity to the stock.")

def add_new_Laptop():
    Laptop_name = input("Enter the name of Laptop: ")
    Brand_name = input("Enter the brand of Laptop: ")
    Laptop_processor = input("Enter the processor of Laptop: ")
    Laptop_graphic = input("Enter the graphic of Laptop: ")

    Laptop_quantity = 0
    while Laptop_quantity < 1:
        try:
            Laptop_quantity = int(input("Enter the quantity of the Laptop: "))
        except:
            print("\nPlease enter a valid number greater than 0\n")

    Laptop_price = 0
    while Laptop_price < 1:
        try:
            Laptop_price = int(input("Enter the price of Laptop: "))
        except:
            print("\nPlease enter a valid number greater than 0\n")
    
    print("\nPlease confirm the details of the new Laptop\n")
    print("Laptop Name: "+Laptop_name+"\nBrand Name: "+Brand_name+"\nPrice: $"+str(Laptop_price)+"\nQuantity:"+str(Laptop_quantity)+"\nProcessor:"+Laptop_processor+"\nGraphic: "+Laptop_graphic)

    print("\nIs is correct?\n1. Yes \n2. No")
    yesno = 0
    while yesno < 1 or yesno > 2:
        try:
            yesno = int(input("Enter the value of option: "))

            if yesno > 2:
                print("\nPlease enter either 1 or 2!\n")
        except:
            print("\nPlease enter either 1 or 2!\n")

    if yesno == 1:
        file = open('Laptop.txt', 'a')
        file.write("\n"+Laptop_name+","+Brand_name+",$"+str(Laptop_price)+","+str(Laptop_quantity)+","+Laptop_processor+","+Laptop_graphic)
        file.close()

        print("\nSuccessfully added the Laptop to the stock!")
    else:
        print("\nPlease enter the details again!\n")
        add_new_Laptop()

def get_user_details():
    print("")
    name = input("Enter your full name: ")
    address = input("Enter your address: ")
    email = input("Enter your email: ")

    phone = ""

    while phone == "":
        try:
            phone = int(input("Enter your phone number: "))
        except:
            print("\nPlease enter valid number for phone!\n")
    
    details = {}
    details["name"] = name
    details["address"] = address
    details["phone"] = phone
    details["email"] = email

    global user_current_details
    user_current_details = details
    
    return details

def exit_system():
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\tThank you for using Laptop Management System")
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

def Laptop_not_found():
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("That Laptop id is not available. Please choose from 1 -", len(get_Laptop_list()))
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    purchase_Laptop()

def purchase_more():
    print("\n")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\tThank you for purchasing")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

    yesno = 0
    print("Would you like to purchase more?\n1. Yes \n2. No ")
    while yesno < 1 or yesno > 2:
        try:
            yesno = int(input("Enter the value of option: "))

            if yesno > 2:
                print("\nPlease enter either 1 or 2!\n")
        except:
            print("\nPlease enter either 1 or 2!\n")

    if yesno == 1:
        purchase_Laptop()

def create_bill(Laptop_id, quantity):
    Laptop_list = get_Laptop_list()
    Laptop = Laptop_list.get(Laptop_id)
    shipping_cost = 100
    if user_current_details == {}:
        user_details = get_user_details()
    else:
        user_details = user_current_details
        
    name = user_details.get("name")
    address = user_details.get("address")
    phone = user_details.get("phone")
    email = user_details.get("email")
    amount_paid = int(Laptop[Price].replace("$", "")) * quantity
    Total_amount = shipping_cost + amount_paid

    Laptop_name = Laptop[Name]
    Brand_name = Laptop[Brand]
    Laptop_price = Laptop[Price]
    date_today = datetime.now().strftime("%Y-%m-%d")
    time = datetime.now().strftime("%H:%M:%S")
    time_today = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    remove_Laptop_stock(Laptop_id, quantity)

    file_name = BILLS_PATH + str(phone) + "_" + name + "_"+ time_today +".txt"
    file = open(file_name, "w")
    content = f"""Name: {name} \nAddress: {address} \nPhone: {phone} \nEmail: {email}\n\nLaptop Name: {Laptop_name} \nBrand Name: {Brand_name} \nPrice: {Laptop_price}\nQuantity purchased: {quantity} \nshipping cost:{shipping_cost} \nAmount Paid: ${amount_paid} \nTotal_amount: {shipping_cost + amount_paid} \nDate: {date_today} \nTime: {time}"""
    file.write(content)
    file.close()
    
    print("\nYour bill\n")
    print(content)

    purchase_more()
    
def add_Laptop_stock(Laptop_id, quantity_to_add):
    Laptop_list = get_Laptop_list()
    Laptop = Laptop_list.get(Laptop_id)
    new_content = []

    read = open("Laptop.txt", "r")

    for line in read:
        detail = line.replace("\n", "").split(",")
        Laptop_quantity = int(detail[Quantity])

        if detail[Name] == Laptop[Name]:
            detail[Quantity] = str(Laptop_quantity + quantity_to_add)
            
        new_content.append(','.join(detail))
    
    read.close()

    file = open("Laptop.txt", "w")
    file.write('\n'.join(new_content))
    file.close()

def remove_Laptop_stock(Laptop_id, quantity_to_remove):
    Laptop_list = get_Laptop_list()
    Laptop = Laptop_list.get(Laptop_id)
    new_content = []

    read = open("Laptop.txt", "r")

    for line in read:
        detail = line.replace("\n", "").split(",")
        Laptop_quantity = int(detail[Quantity])

        if detail[Name] == Laptop[Name]:
            detail[Quantity] = str(Laptop_quantity - quantity_to_remove)
            
        new_content.append(','.join(detail))
    
    read.close()

    file = open("Laptop.txt", "w")
    file.write('\n'.join(new_content))
    file.close()
    

def out_of_stock(Laptop_name):
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\t", Laptop_name, "is currently out of stock!")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
       
def less_stock(name, quantity):
    print("\n")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("\tThe quantity you need of", name, "is not available.")
    print("\tAvailable Quantity:", quantity)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    

def purchase_Laptop():
    Laptop_list = get_Laptop_list()

    loop = True
    while loop == True:
        display_Laptops()
        print("\n")
        Laptop_id = 0
        while Laptop_id == 0:
            try:
                Laptop_id = int(input("Enter the id of the Laptop you want to purchase: "))
            except:
                print("Please enter valid number for Laptop id!")

        if Laptop_id > len(Laptop_list) or Laptop_id < 1:
            Laptop_not_found()
        else:
            validate_quantity(Laptop_id)
            loop = False

def validate_quantity(Laptop_id):
    Laptop_list = get_Laptop_list()
    
    Laptop = Laptop_list.get(Laptop_id)
    name = Laptop[Name]
    quantity = int(Laptop[Quantity])
    
    if quantity > 1:
        loop = True
        while loop == True:
            purchase_quantity = 0

            while purchase_quantity == 0:
                try:
                    purchase_quantity = int(input("Enter the quantity you want to purchase: "))
                except:
                    print("\nPlease enter valid number for quantity!\n")
            
            if purchase_quantity > 0:
                if quantity >= purchase_quantity:
                    loop = False
                    
                    create_bill(Laptop_id, purchase_quantity)
                else:
                    less_stock(name, quantity)
            else:
                print("Please enter a valid amount!")
    else:
        out_of_stock(name)
